extern int rpathy_value ();
int main () { return !(rpathy_value () == 57); }
